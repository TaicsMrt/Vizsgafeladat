// Karusszel logika
const slides = document.querySelectorAll('.carousel-slide');
const prevButton = document.querySelector('.carousel-prev');
const nextButton = document.querySelector('.carousel-next');
let currentSlide = 0;

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
    });
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    showSlide(currentSlide);
}

// Automatikus váltás
setInterval(nextSlide, 5000);

// Gombok eseménykezelése
prevButton.addEventListener('click', prevSlide);
nextButton.addEventListener('click', nextSlide);

// Kezdő slide
showSlide(currentSlide);

// Dinamikus év a láblécben
document.getElementById('year').textContent = new Date().getFullYear();