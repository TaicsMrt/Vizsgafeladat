const users = [];

document.getElementById("loginBtn").addEventListener("click", () => {
    const username = prompt("Add meg a felhasználóneved:");
    const password = prompt("Add meg a jelszavad:");

    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        alert(`Üdvözlünk, ${username}!`);
    } else {
        alert("Hibás felhasználónév vagy jelszó!");
    }
});

document.getElementById("registerBtn").addEventListener("click", () => {
    const username = prompt("Válassz egy felhasználónevet:");
    const password = prompt("Válassz egy jelszót:");

    if (username && password) {
        users.push({ username, password });
        alert("Sikeres regisztráció!");
    } else {
        alert("A regisztráció sikertelen! Mindkét mezőt ki kell tölteni.");
    }
});
let movableTableContainer = document.getElementById('movableTableContainer');
let isMouseDown = false;
let offset = { x: 0, y: 0 };

movableTableContainer.addEventListener('mousedown', (e) => {
    isMouseDown = true;
    offset.x = movableTableContainer.offsetLeft - e.clientX;
    offset.y = movableTableContainer.offsetTop - e.clientY;
});

document.addEventListener('mousemove', (e) => {
    if (isMouseDown) {
        movableTableContainer.style.left = e.clientX + offset.x + 'px';
        movableTableContainer.style.top = e.clientY + offset.y + 'px';
    }
});

document.addEventListener('mouseup', () => {
    isMouseDown = false;
});
