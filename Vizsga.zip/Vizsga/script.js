const users = [];

document.getElementById("loginBtn").addEventListener("click", () => {
    const username = prompt("Add meg a felhasználóneved:");
    const password = prompt("Add meg a jelszavad:");

    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        alert(`Üdvözlünk, ${username}!`);
    } else {
        alert("Hibás felhasználónév vagy jelszó!");
    }
});

document.getElementById("registerBtn").addEventListener("click", () => {
    const username = prompt("Válassz egy felhasználónevet:");
    const password = prompt("Válassz egy jelszót:");

    if (username && password) {
        users.push({ username, password });
        alert("Sikeres regisztráció!");
    } else {
        alert("A regisztráció sikertelen! Mindkét mezőt ki kell tölteni.");
    }
});