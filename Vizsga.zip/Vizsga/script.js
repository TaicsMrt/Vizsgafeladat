// Üzenetek betöltése a localStorage-ból
function loadMessages() {
    const chatbox = document.getElementById('chatbox');
    const messages = JSON.parse(localStorage.getItem('chatMessages')) || [];
    chatbox.innerHTML = messages.map(msg => `<p>${msg}</p>`).join('');
    chatbox.scrollTop = chatbox.scrollHeight; // Görgetés az aljára
}

// Üzenet küldése
function sendMessage() {
    const inputField = document.getElementById('messageInput');
    const message = inputField.value.trim();
    
    if (message !== "") {
        const messages = JSON.parse(localStorage.getItem('chatMessages')) || [];
        messages.push(message);
        localStorage.setItem('chatMessages', JSON.stringify(messages));

        // Üzenet hozzáadása a chatbox-hoz
        loadMessages();
        inputField.value = ""; // Üzenet mező törlése
    }
}

// Eseménykezelők
document.getElementById('sendBtn').addEventListener('click', sendMessage);
document.getElementById('messageInput').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
});

// Üzenetek betöltése oldal betöltésekor
loadMessages();
