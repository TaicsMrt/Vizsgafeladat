function openModal(type) {
     const modal = document.getElementById('modal');
     const modalTitle = document.getElementById('modal-title');
     modal.style.display = 'flex';
   
     if (type === 'reg') {
       modalTitle.textContent = 'Regisztráció';
     } else if (type === 'login') {
       modalTitle.textContent = 'Belépés';
     }
   }
   
   function closeModal() {
     const modal = document.getElementById('modal');
     modal.style.display = 'none';
   }
   
   function changeText(newText) {
     document.getElementById('introduction').textContent = newText;
   }
     // A balra csúszó menü megjelenítéséért és eltüntetéséért felelős JavaScript függvény
     function toggleMenu() {
      const sidenav = document.getElementById("mySidenav");
      // Ha a menü zárt, akkor nyisd ki, ha pedig nyitva van, akkor zárd be
      if (sidenav.style.width === "250px") {
        sidenav.style.width = "0";
      } else {
        sidenav.style.width = "250px";
      }
    }
 