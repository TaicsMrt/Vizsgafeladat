const loginform=document.getElementById("loginform")
const switchtoregister=document.getElementById("switchtoregister")

switchtoregister.addEventListener("click",()=>{
    loginform.style.display="none";
    registerform.style.display="block";
});

loginform.addEventListener("submit",(e)=>{
    e.preventDefault();
    const email=document.getElementById("logemail").value;
    const password=document.getElementById("logpassword").value;
    const storeduser=JSON.parse(localStorage.getItem('user'))
    if ( storeduser.email===email && storeduser.password===password ){
        alert("sikeres bejelentkezés");
        window.location.href="../tortenet.html"
    }
    else{
        alert(`sikertelen bejelentekzés${storeduser.email} ${storeduser.password} ${email} ${password}`)
    }
    
});