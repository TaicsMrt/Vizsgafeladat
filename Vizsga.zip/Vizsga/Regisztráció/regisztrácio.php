<?php
// Adatbázis kapcsolat
$servername = "localhost";
$username = "root"; // Alapértelmezett felhasználó
$password = "";     // Jelszó, ha van beállítva
$dbname = "boston";

// Kapcsolat létrehozása
$conn = new mysqli($servername, $username, $password, $dbname);

// Kapcsolat ellenőrzése
if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

// Űrlap adatok fogadása
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $felhasznalonev = $_POST['username'];
    $email = $_POST['regiemail'];
    $jelszo = password_hash($_POST['regipassword'], PASSWORD_DEFAULT);

    // Adatok beszúrása az adatbázisba
    $sql = "INSERT INTO felhasznalok (felhasznalonev, email, jelszo_hash, letrehozva) 
            VALUES ('$felhasznalonev', '$email', '$jelszo', NOW())";

    if ($conn->query($sql) === TRUE) {
        echo "Sikeres regisztráció!";
        header("Location: login.html");
        exit();
    } else {
        echo "Hiba: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
