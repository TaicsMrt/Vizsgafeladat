const registerform=document.getElementById("registerform")
const loginform=document.getElementById("loginform")
const switchtologin=document.getElementById("switchtologin")
const switchtoregister=document.getElementById("switchtoregister")

switchtologin.addEventListener("click", ()=>{
    registerform.style.display="none";
    loginform.style.display="block";
});
switchtoregister.addEventListener("click",()=>{
    loginform.style.display="none";
    registerform.style.display="block";
});


registerform.addEventListener("submit",(e)=>{
    e.preventDefault();
    const username=document.getElementById("username").vaule;
    const password=document.getElementById("regipassword").value;
    const email=document.getElementById("regiemail").value;
    localStorage.setItem("user",JSON.stringify({username,email,password}))
    alert("sikeres regisztráció");
    window.location.href="login.html"

});

loginform.addEventListener("submit",(e)=>{
    e.preventDefault();
    const email=document.getElementById("logemail")
    const password=document.getElementById("logpassword")
    const storeduser=JSON.parse(localStorage.getItem('user'))
    if (storeduser && storeduser.email==email && storeduser.password==password ){
        alert("sikeres bejelentkezés");
        window.location.href="C:\Users\taimar487\Downloads\Vizsga\tortenet.html"
    };
    
});

