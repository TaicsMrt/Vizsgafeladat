<?php
// Adatbázis kapcsolat
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boston";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

// Bejelentkezés ellenőrzése
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['logemail'];
    $jelszo = $_POST['logpassword'];

    $sql = "SELECT * FROM felhasznalok WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($jelszo, $row['jelszo_hash'])) {
            echo "Sikeres bejelentkezés!";
            header("Location: succeslogin.html");
            exit();
        } else {
            echo "Hibás jelszó!";
        }
    } else {
        echo "Nincs ilyen email címmel regisztrált felhasználó!";
    }
}

$conn->close();
?>
