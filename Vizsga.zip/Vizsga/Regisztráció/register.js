const registerform = document.getElementById("registerform");

registerform.addEventListener("submit", (e) => {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("regipassword").value.trim();
    const email = document.getElementById("regiemail").value.trim();

    // Ellenőrzés: üres mezők
    if (!username || !password || !email) {
        alert("Kérjük, töltse ki az összes mezőt a regisztrációhoz!");
        return;
    }

    // Email formátum ellenőrzése regex-szel
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Alap email ellenőrző minta

    if (!emailPattern.test(email)) {
        alert("Nem megfelelő az email formátuma. Kérjük, adjon meg egy érvényes email címet (pl.: valami@valami.hu).");
        return;
    }
    const registerform = document.getElementById("registerform");

registerform.addEventListener("submit", (e) => {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("regipassword").value.trim();
    const email = document.getElementById("regiemail").value.trim();

    // Hibák alapértelmezetten rejtve
    document.getElementById("emailError").style.display = "none";
    document.getElementById("usernameError").style.display = "none";
    document.getElementById("passwordError").style.display = "none";

    // Ellenőrzés: üres mezők
    let formIsValid = true;

    if (!username) {
        document.getElementById("usernameError").style.display = "block"; // Megjelenítjük a hibát
        formIsValid = false;
    }

    if (!password) {
        document.getElementById("passwordError").style.display = "block"; // Megjelenítjük a hibát
        formIsValid = false;
    }

    if (!email) {
        document.getElementById("emailError").style.display = "block"; // Megjelenítjük a hibát
        formIsValid = false;
    } else {
        // Email formátum ellenőrzése regex-szel
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Alap email ellenőrző minta

        if (!emailPattern.test(email)) {
            document.getElementById("emailError").style.display = "block"; // Megjelenítjük a hibát
            document.getElementById("emailError").textContent = "Nem megfelelő az email formátuma.";
            formIsValid = false;
        }
    }

    // Ha minden rendben van, regisztrálunk
    if (formIsValid) {
        localStorage.setItem("user", JSON.stringify({ username, email, password }));
        alert("Sikeres regisztráció!");
        window.location.href = "login.html";
    }
});


    // Sikeres regisztráció
    localStorage.setItem("user", JSON.stringify({ username, email, password }));
    alert("Sikeres regisztráció!");
    window.location.href = "login.html";
});
