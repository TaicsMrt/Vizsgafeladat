document.addEventListener("DOMContentLoaded", function () {
    const button = document.querySelector("button");
    let isStartingFive = true;

    // Két különböző kezdőötös játékoslisták
    const startingFive = [
        { name: "Derrick White", age: "30", height: "1,93 m", position: "Irányító", img: "Pics/DW.png" },
        { name: "Jayson Tatum", age: "26", height: "2,03 m", position: "Erőcsatár", img: "Pics/JT.jpg" },
        { name: "Al Horford", age: "38", height: "2,06 m", position: "Center", img: "Pics/AH.jpg" },
        { name: "Baylor Scheierman", age: "24", height: "1,98 m", position: "Dobóhátvéd", img: "Pics/BS.jpg" },
        { name: "Jaylen Brown", age: "28", height: "1,98 m", position: "Kiscsatár", img: "Pics/JB.webp" }
    ];

    const benchPlayers = [
        { name: "Jrue Holiday", age: "33", height: "1,93 m", position: "Irányító", img: "Pics/JH.jpg" },
        { name: "Kristaps Porzingis", age: "28", height: "2,21 m", position: "Erőcsatár", img: "Pics/KP.jpg" },
        { name: "Luke Kornet", age: "28", height: "2,18 m", position: "Center", img: "Pics/LK.jpg" },
        { name: "Sam Hauser", age: "26", height: "2,01 m", position: "Dobóhátvéd", img: "Pics/SH.jpg" },
        { name: "Payton Pritchard", age: "26", height: "1,85 m", position: "Kiscsatár", img: "Pics/PP.jpg" }
    ];

    function updateCards(players) {
        players.forEach((player, index) => {
            let card = document.getElementById(`card${index + 1}`);
            card.querySelector(".back-content strong").textContent = player.position;
            card.querySelector(".img").style.backgroundImage = `url('${player.img}')`;
            card.querySelector(".title p strong").textContent = player.name;
            card.querySelector(".card-footer").textContent = `Kor: ${player.age} | Magasság: ${player.height}`;
        });
    }

    button.addEventListener("click", function () {
        if (isStartingFive) {
            updateCards(benchPlayers);
            button.textContent = "Kezdőötös";
        } else {
            updateCards(startingFive);
            button.textContent = "Cserék";
        }
        isStartingFive = !isStartingFive;
    });
});
