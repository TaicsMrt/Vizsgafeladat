document.getElementById('registerButton').addEventListener('click', function() {
    document.getElementById('message').style.display = 'block';
    document.getElementById('registerButton').style.display = 'none';
});

document.getElementById('startQuizButton').addEventListener('click', function() {
    document.getElementById('quiz-container').style.display = 'block';
    document.getElementById('message').style.display = 'none';
});

document.getElementById('submitQuiz').addEventListener('click', function() {
    let score = 0;
    const correctAnswers = ['a', 'a', 'a', 'b', 'b', 'a', 'a', 'a', 'a', 'b']; 

    for (let i = 1; i <= 10; i++) {  
        let selectedAnswer = document.querySelector(`input[name="q${i}"]:checked`);
        if (selectedAnswer && selectedAnswer.value === correctAnswers[i - 1]) {
            score++;
        }
    }

    if (score >= 7) {
        document.getElementById('quiz-container').style.display = 'none';
        document.getElementById('registration-form').style.display = 'block';
    } else {
        alert('A teszt nem sikerült. Kérlek próbáld újra.');
    }
});

document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    document.getElementById('registration-form').style.display = 'none';
    document.getElementById('successMessage').style.display = 'block';
});
