document.addEventListener("DOMContentLoaded", function () {
     const calendar = document.getElementById("calendar").querySelector("tbody");
     const currentMonthYear = document.getElementById("currentMonthYear");
     const prevMonthBtn = document.getElementById("prevMonth");
     const nextMonthBtn = document.getElementById("nextMonth");
  
     let today = new Date();
     let currentYear = today.getFullYear();
     let currentMonth = today.getMonth();
  
     function updateCalendar(year, month) {
         calendar.innerHTML = "";
         let firstDay = new Date(year, month, 1).getDay();
         let lastDate = new Date(year, month + 1, 0).getDate();
  
         let monthNames = [
             "Január", "Február", "Március", "Április", "Május", "Június",
             "Július", "Augusztus", "Szeptember", "Október", "November", "December"
         ];
        
         currentMonthYear.textContent = `${monthNames[month]} ${year}`;
  
         let row = document.createElement("tr");
         let dayOffset = firstDay === 0 ? 6 : firstDay - 1;
  
         for (let i = 0; i < dayOffset; i++) {
             row.appendChild(document.createElement("td"));
         }
  
         for (let day = 1; day <= lastDate; day++) {
             let cell = document.createElement("td");
             cell.textContent = day;
  
             if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
                 cell.classList.add("today");
             }
  
             row.appendChild(cell);
  
             if ((day + dayOffset) % 7 === 0) {
                 calendar.appendChild(row);
                 row = document.createElement("tr");
             }
         }
  
         if (row.childNodes.length > 0) {
             calendar.appendChild(row);
         }
     }
  
     prevMonthBtn.addEventListener("click", function () {
         currentMonth--;
         if (currentMonth < 0) {
             currentMonth = 11;
             currentYear--;
         }
         updateCalendar(currentYear, currentMonth);
     });
  
     nextMonthBtn.addEventListener("click", function () {
         currentMonth++;
         if (currentMonth > 11) {
             currentMonth = 0;
             currentYear++;
         }
         updateCalendar(currentYear, currentMonth);
     });
  
     updateCalendar(currentYear, currentMonth);
 });
  
  