// Chat funkcionalitás
document.addEventListener("DOMContentLoaded", function () {
    const chatMessages = document.getElementById("chat-messages");
    const messageInput = document.getElementById("message-input");
    let username = "Vendég" + Math.floor(Math.random() * 1000); // Véletlenszerű felhasználónév

    // Üzenet küldése
    function sendMessage() {
        const messageText = messageInput.value.trim();
        if (messageText) {
            const message = {
                user: username,
                text: messageText,
                time: new Date().toLocaleTimeString()
            };
            addMessage(message);
            messageInput.value = "";
            scrollToBottom();
        }
    }

    // Üzenet megjelenítése
    function addMessage(message) {
        const messageElement = document.createElement("div");
        messageElement.className = "chat-message";
        messageElement.innerHTML = `
            <strong>${message.user}</strong> <span class="message-time">[${message.time}]</span><br>
            ${message.text}
        `;
        chatMessages.appendChild(messageElement);
        messageElement.scrollIntoView({ behavior: "smooth" });
    }

    // Enter billentyű támogatás
    messageInput.addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            sendMessage();
        }
    });

    // Chat ablak aljára görgetés
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Példaüzenetek betöltése (opcionális)
    const exampleMessages = [
        { user: "CelticsFan", text: "Go Celtics!", time: new Date().toLocaleTimeString() },
        { user: "GreenTeam", text: "17 bajnoki cím, hihetetlen!", time: new Date().toLocaleTimeString() }
    ];
    exampleMessages.forEach(addMessage);
});