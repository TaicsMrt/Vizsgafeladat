document.addEventListener('DOMContentLoaded', function() {
    const userList = document.getElementById('userList');

    // Felhasználók betöltése az admin panelbe
    function loadUsers() {
        fetch('get_users.php')
        .then(response => response.json())
        .then(data => {
            userList.innerHTML = ''; // Töröljük a korábbi listát
            data.users.forEach(user => {
                const li = document.createElement('li');
                li.textContent = `${user.username} (${user.role})`;
                if (user.role === 'user') {
                    const button = document.createElement('button');
                    button.textContent = 'Adminná tétele';
                    button.addEventListener('click', () => {
                        updateUserRole(user.id, 'admin');
                    });
                    li.appendChild(button);
                }
                userList.appendChild(li);
            });
        })
        .catch(error => {
            console.error('Hiba történt a felhasználók betöltése során:', error);
        });
    }

    // Felhasználó jogosultságának módosítása
    function updateUserRole(userId, role) {
        fetch('update_role.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ userId, role })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadUsers(); // Frissítjük a felhasználók listáját
            } else {
                console.error('Hiba történt a jogosultság módosítása során:', data.message);
            }
        })
        .catch(error => {
            console.error('Hiba történt a jogosultság módosítása során:', error);
        });
    }

    // Csak akkor töltjük be a felhasználókat, ha az admin panel látható
    if (document.getElementById('adminPanel')) {
        loadUsers();
    }
});