<?php
session_start(); // Session indítása
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'];
$password = $data['password'];

$conn = new mysqli('localhost', 'root', '', 'user_management');
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$stmt = $conn->prepare('SELECT id, password, role FROM users WHERE username = ?');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id, $hashed_password, $role);

if ($stmt->fetch() && password_verify($password, $hashed_password)) {
    // Session-be mentjük a felhasználó adatait
    $_SESSION['user_id'] = $id;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Hibás felhasználónév vagy jelszó']);
}

$stmt->close();
$conn->close();
?>