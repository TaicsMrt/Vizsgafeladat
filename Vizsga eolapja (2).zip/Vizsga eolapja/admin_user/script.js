document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const loginLink = document.getElementById('loginLink'); // "Jelentkezz be" link
    const registerLink = document.getElementById('registerLink'); // "Regisztrálj" link
    const loginError = document.getElementById('loginError');
    const registerError = document.getElementById('registerError');

    // Váltás a bejelentkezés és regisztráció között
    registerLink.addEventListener('click', function(e) {
        e.preventDefault(); // Megakadályozzuk az oldal újratöltését
        loginForm.classList.remove('active');
        registerForm.classList.add('active');
        loginError.style.display = 'none'; // Elrejtjük a bejelentkezési hibát
        registerError.style.display = 'none'; // Elrejtjük a regisztrációs hibát
    });

    loginLink.addEventListener('click', function(e) {
        e.preventDefault(); // Megakadályozzuk az oldal újratöltését
        registerForm.classList.remove('active');
        loginForm.classList.add('active');
        loginError.style.display = 'none'; // Elrejtjük a bejelentkezési hibát
        registerError.style.display = 'none'; // Elrejtjük a regisztrációs hibát
    });

    // Bejelentkezés
    document.getElementById('login').addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        fetch('login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'dashboard.php'; // Átirányítás a dashboardra
            } else {
                loginError.textContent = data.message;
                loginError.style.display = 'block'; // Hibaüzenet megjelenítése
            }
        })
        .catch(error => {
            console.error('Hiba történt:', error);
            loginError.textContent = 'Hiba történt a bejelentkezés során.';
            loginError.style.display = 'block';
        });
    });

    // Regisztráció
    document.getElementById('register').addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('regUsername').value;
        const email = document.getElementById('regEmail').value;
        const password = document.getElementById('regPassword').value;

        fetch('register.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                registerError.textContent = 'Sikeres regisztráció!';
                registerError.style.color = 'green';
                registerError.style.display = 'block';
                registerForm.classList.remove('active');
                loginForm.classList.add('active');
            } else {
                registerError.textContent = data.message;
                registerError.style.color = 'red';
                registerError.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Hiba történt:', error);
            registerError.textContent = 'Hiba történt a regisztráció során.';
            registerError.style.color = 'red';
            registerError.style.display = 'block';
        });
    });
});