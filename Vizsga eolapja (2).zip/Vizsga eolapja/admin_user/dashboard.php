<?php
session_start(); // Session indítása

// Ha nincs bejelentkezve, visszairányítás a bejelentkezési oldalra
if (!isset($_SESSION['user_id'])) {
    header('Location: index.html');
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'user_management');
if ($conn->connect_error) {
    die('Adatbázis kapcsolódási hiba');
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare('SELECT username, role FROM users WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($username, $role);
$stmt->fetch();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Üdvözöljük, <?php echo htmlspecialchars($username); ?>!</h1>
        <p>Ön <?php echo ($role === 'admin') ? 'admin' : 'felhasználó'; ?> jogosultsággal rendelkezik.</p>
        <a href="logout.php">Kijelentkezés</a>

        <!-- Admin panel (csak adminoknak) -->
        <?php if ($role === 'admin'): ?>
            <div id="adminPanel">
                <h2>Admin Panel</h2>
                <div class="box">
                    <p>Felhasználók listája:</p>
                    <ul id="userList"></ul>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="dashboard.js"></script>
</body>
</html>