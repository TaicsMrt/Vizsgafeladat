<?php
header('Content-Type: application/json');

$conn = new mysqli('localhost', 'root', '', 'user_management');
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$result = $conn->query('SELECT id, username, role FROM users');
$users = [];

while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

echo json_encode(['success' => true, 'users' => $users]);

$conn->close();
?>