<?php
session_start(); // Session indítása
session_destroy(); // Session törlése
header('Location: index.html'); // Visszairányítás a bejelentkezési oldalra
exit();
?>