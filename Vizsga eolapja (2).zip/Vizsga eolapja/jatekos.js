document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.querySelector(".toggle-button");
    let isStartingFive = true;

    const startingFive = [
        { name: "Derrick White", age: "30", height: "1,93 m", position: "Irányító", img: "Pics/DW.png" },
        { name: "Jayson Tatum", age: "26", height: "2,03 m", position: "Erőcsatár", img: "Pics/JT.jpg" },
        { name: "Al Horford", age: "38", height: "2,06 m", position: "Center", img: "Pics/AH.jpg" },
        { name: "Baylor Scheierman", age: "24", height: "1,98 m", position: "Dobóhátvéd", img: "Pics/BS.jpg" },
        { name: "Jaylen Brown", age: "28", height: "1,98 m", position: "Kiscsatár", img: "Pics/JB.webp" }
    ];

    const benchPlayers = [
        { name: "Jrue Holiday", age: "33", height: "1,93 m", position: "Irányító", img: "Pics/JH.jpg" },
        { name: "Kristaps Porzingis", age: "28", height: "2,21 m", position: "Erőcsatár", img: "Pics/KP.jpg" },
        { name: "Luke Kornet", age: "28", height: "2,18 m", position: "Center", img: "Pics/LK.jpg" },
        { name: "Sam Hauser", age: "26", height: "2,01 m", position: "Dobóhátvéd", img: "Pics/SH.jpg" },
        { name: "Payton Pritchard", age: "26", height: "1,85 m", position: "Kiscsatár", img: "Pics/PP.jpg" }
    ];

    function createCard(player, cardId) {
        const card = document.getElementById(cardId);
        if (card) {
            card.innerHTML = `
                <div class="content">
                    <div class="img" style="background-image: url('${player.img}')"></div>
                    <div class="description">
                        <div class="title">
                            <p><strong>${player.name}</strong></p>
                        </div>
                        <div class="card-footer">
                            <span class="info-item">Kor: ${player.age}</span>
                            <span class="info-item">Magasság: ${player.height}</span>
                        </div>
                    </div>
                    <div class="position">${player.position}</div>
                </div>
            `;
        } else {
            console.error(`Nem található ${cardId} kártya`);
        }
    }

    function updateCards(players) {
        players.forEach((player, index) => {
            createCard(player, `card${index + 1}`);
        });
    }

    toggleButton.addEventListener("click", function () {
        if (isStartingFive) {
            updateCards(benchPlayers);
            toggleButton.textContent = "Kezdőötös";
        } else {
            updateCards(startingFive);
            toggleButton.textContent = "Cserék";
        }
        isStartingFive = !isStartingFive;
    });

    // Alapértelmezésben betöltjük a kezdőötöst
    updateCards(startingFive);
});