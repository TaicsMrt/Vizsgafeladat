<?php
session_start();
require_once 'config.php'; // adatbázis kapcsolat

// Bejelentkezés
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $resultStmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $resultStmt->bind_param("s", $email);
    $resultStmt->execute();
    $result = $resultStmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Sikeres bejelentkezés esetén mentjük a session adatokat
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            // Átirányítás az index.html-re
            header("Location: index.html");
            exit();
        }
    }

    // Ha az adatok hibásak, vissza az index.php-re hibaüzenettel
    $_SESSION['login_error'] = "Hibás email cím vagy jelszó";
    $_SESSION['active_form'] = "login";
    header("Location: index.php");
    exit();
}

// Regisztráció (ez a rész változatlan maradhat, ha nem kell módosítani)
if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'] ?? 'user'; // Alapértelmezett szerepkör, ha nincs megadva

    // Ellenőrzés, hogy létezik-e már ilyen email
    $checkEmailStmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $checkEmailStmt->bind_param("s", $email);
    $checkEmailStmt->execute();
    $checkEmailResult = $checkEmailStmt->get_result();

    if ($checkEmailResult->num_rows > 0) {
        $_SESSION['register_error'] = 'Ez az email cím már regisztrálva van!';
        $_SESSION['active_form'] = 'register';
    } else {
        // Regisztrálás
        $insertStmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $insertStmt->bind_param("ssss", $name, $email, $password, $role);
        $insertStmt->execute();

        $_SESSION['register_success'] = 'Registration successful!';
    }

    header("Location: index.html");
    exit();
}
?>