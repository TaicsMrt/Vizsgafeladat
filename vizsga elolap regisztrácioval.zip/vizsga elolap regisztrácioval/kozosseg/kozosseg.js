document.addEventListener("DOMContentLoaded", function () {
    const chatMessages = document.getElementById("chat-messages");
    const messageInput = document.getElementById("message-input");
    let username = "Vendég" + Math.floor(Math.random() * 1000);

    // Üzenet küldése
    function sendMessage() {
        const messageText = messageInput.value.trim();
        if (messageText) {
            const currentTime = new Date();
            const message = {
                user: username,
                text: messageText,
                time: currentTime.toLocaleTimeString('hu-HU', { 
                    hour: '2-digit', 
                    minute: '2-digit', 
                    second: '2-digit' 
                })
            };
            addMessage(message);
            messageInput.value = "";
            scrollToBottom();
        }
    }

    // Üzenet megjelenítése
    function addMessage(message) {
        const messageElement = document.createElement("div");
        messageElement.className = "chat-message";
        messageElement.innerHTML = `
            <strong>${message.user}</strong> 
            <span class="message-time">[${message.time}]</span><br>
            ${message.text}
        `;
        chatMessages.appendChild(messageElement);
        messageElement.scrollIntoView({ behavior: "smooth" });
    }

    // Enter billentyű támogatás
    messageInput.addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            sendMessage();
        }
    });

    // Chat ablak aljára görgetés
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Példaüzenetek betöltése
    const exampleMessages = [
        { 
            user: "CelticsFan", 
            text: "Go Celtics!", 
            time: new Date().toLocaleTimeString('hu-HU', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit' 
            }) 
        },
        { 
            user: "GreenTeam", 
            text: "17 bajnoki cím, hihetetlen!", 
            time: new Date().toLocaleTimeString('hu-HU', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit' 
            }) 
        }
    ];
    exampleMessages.forEach(addMessage);

    // Küldés gomb eseménykezelő hozzáadása
    const sendButton = document.querySelector(".chat-send-btn");
    sendButton.addEventListener("click", sendMessage);

    // Dinamikus évszám beállítása a footerben
    document.getElementById('year').textContent = new Date().getFullYear();

    // "Lépj be a chatbe!" gomb görgetése a chat szekcióhoz
    const heroButton = document.querySelector(".hero-button");
    heroButton.addEventListener("click", function () {
        const chatSection = document.querySelector(".chat-section");
        chatSection.scrollIntoView({ behavior: "smooth" });
    });
});