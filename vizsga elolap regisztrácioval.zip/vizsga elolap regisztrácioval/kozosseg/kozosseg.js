document.addEventListener("DOMContentLoaded", function () {
    const chatMessages = document.getElementById("chat-messages");
    const messageInput = document.getElementById("message-input");

    // Üzenet küldése
    function sendMessage() {
        const messageText = messageInput.value.trim();
        if (messageText) {
            const currentTime = new Date();
            const message = {
                user: username, // A username most már globálisan definiált
                text: messageText,
                time: currentTime.toLocaleTimeString('hu-HU', { 
                    hour: '2-digit', 
                    minute: '2-digit', 
                    second: '2-digit' 
                })
            };
            addMessage(message, true);
            messageInput.value = "";
            scrollToBottom();
        }
    }

    // Üzenet megjelenítése
    function addMessage(message, isMyMessage = false) {
        const messageElement = document.createElement("div");
        messageElement.classList.add("chat-message");
        messageElement.classList.add(isMyMessage ? "my-message" : "other-message");

        // Felhasználónév és idő hozzáadása
        const userTime = document.createElement("div");
        userTime.innerHTML = `<strong>${message.user}</strong> <span class="message-time">${message.time}</span>`;
        
        const contentSpan = document.createElement("span");
        contentSpan.classList.add("message-content");
        contentSpan.textContent = message.text;

        messageElement.appendChild(userTime);
        messageElement.appendChild(contentSpan);

        chatMessages.appendChild(messageElement);
        messageElement.scrollIntoView({ behavior: "smooth" });
    }

    // Enter billentyű támogatás
    messageInput.addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            sendMessage();
        }
    });

    // Chat ablak aljára görgetés
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Példaüzenetek betöltése
    const exampleMessages = [
        { 
            user: "CelticsFan", 
            text: "Szia, hogy vagy?", 
            time: new Date().toLocaleTimeString('hu-HU', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit' 
            }) 
        },
        { 
            user: "GreenTeam", 
            text: "Jól vagyok, köszi!", 
            time: new Date().toLocaleTimeString('hu-HU', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit' 
            }) 
        }
    ];
    exampleMessages.forEach(msg => addMessage(msg, false));

    // Küldés gomb eseménykezelő
    const sendButton = document.querySelector(".chat-send-btn");
    sendButton.addEventListener("click", sendMessage);

    // Dinamikus évszám a footerben
    document.getElementById('year').textContent = new Date().getFullYear();

    // "Lépj be a chatbe!" gomb görgetése
    const heroButton = document.querySelector(".hero-button");
    heroButton.addEventListener("click", function () {
        const chatSection = document.querySelector(".chat-section");
        chatSection.scrollIntoView({ behavior: "smooth" });
    });
});