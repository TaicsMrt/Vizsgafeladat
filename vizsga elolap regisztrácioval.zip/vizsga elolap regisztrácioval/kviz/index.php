<?php
session_start();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boston Celtics Kvíz</title>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Exo 2', sans-serif;
            color: #FFFFFF;
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px;
            min-height: 100vh;
            background: linear-gradient(45deg, #000000, #005122, #36a661, #536159);
            background-size: 400% 400%;
            animation: cyberGradient 20s ease infinite;
        }

        @keyframes cyberGradient {
            0% { background-position: 0% 0%; }
            50% { background-position: 100% 100%; }
            100% { background-position: 0% 0%; }
        }

        h1 {
            text-align: center;
            color: #FFFFFF;
            text-shadow: 0 0 20px #007A33, 0 0 40px #FFFFFF;
            font-size: 3em;
            margin-bottom: 50px;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        #quiz-container {
            background: rgba(0, 0, 0, 0.7);
            padding: 30px;
            border-radius: 0;
            border: 2px solid #007A33;
            box-shadow: 0 0 30px rgba(0, 122, 51, 0.5);
            backdrop-filter: blur(10px);
        }

        .question {
            margin-bottom: 25px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.05);
            border-left: 4px solid #007A33;
            transition: all 0.3s ease;
        }

        .question:hover {
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.3);
        }

        input[type="radio"] {
            accent-color: #007A33;
            margin-right: 15px;
            transform: scale(1.2);
        }

        label {
            font-size: 1.2em;
            color: #FFFFFF;
            text-shadow: 0 0 5px rgba(0, 122, 51, 0.8);
            transition: color 0.3s ease;
        }

        label:hover {
            color: #FFFFFF;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.8);
        }

        button {
            display: block;
            margin: 40px auto;
            padding: 15px 50px;
            background: transparent;
            color: #FFFFFF;
            border: 2px solid #007A33;
            border-radius: 0;
            font-size: 1.3em;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 2px;
            box-shadow: 0 0 20px rgba(0, 122, 51, 0.5);
        }

        button:hover {
            background: #007A33;
            color: #FFFFFF;
            box-shadow: 0 0 40px rgba(0, 122, 51, 0.9);
            border-color: #FFFFFF;
        }

        #result {
            text-align: center;
            margin-top: 40px;
            font-size: 1.5em;
            text-shadow: 0 0 15px #007A33;
            letter-spacing: 1px;
        }

        #timer {
            text-align: center;
            font-size: 1.5em;
            margin-bottom: 20px;
            color: #FFFFFF;
            text-shadow: 0 0 10px #007A33;
        }
    </style>
</head>
<body>
    <h1>Boston Celtics Kvíz</h1>
    <div id="timer">Hátralévő idő: 3:00</div>
    <div id="quiz-container"></div>
    <button onclick="checkAnswers()">Kész</button>
    <div id="result"></div>

    <script>
        const allQuestions = [
            { question: "Mikor alapították a Boston Celtics-et?", answers: ["1946", "1950", "1960", "1936"], correct: "1946" },
            { question: "Hány bajnokságot nyert a Celtics?", answers: ["15", "17", "19", "13"], correct: "17" },
            { question: "Ki a Celtics legendás center játékosa?", answers: ["Larry Bird", "Bill Russell", "Paul Pierce", "Kevin Garnett"], correct: "Bill Russell" },
            { question: "Melyik színek a Celtics hivatalos színei?", answers: ["Zöld-Fehér", "Kék-Piros", "Fekete-Sárga", "Zöld-Kék"], correct: "Zöld-Fehér" },
            { question: "Hol játszik hazai mérkőzéseit a Celtics?", answers: ["Madison Square Garden", "TD Garden", "Staples Center", "Barclays Center"], correct: "TD Garden" },
            { question: "Ki volt a Celtics edzője a 2008-as bajnoki cím idején?", answers: ["Doc Rivers", "Brad Stevens", "Red Auerbach", "Rick Pitino"], correct: "Doc Rivers" },
            { question: "Melyik évben draftolták Jayson Tatumot?", answers: ["2015", "2016", "2017", "2018"], correct: "2017" },
            { question: "Ki nyerte a legtöbb bajnoki gyűrűt a Celtics játékosaként?", answers: ["Bill Russell", "Larry Bird", "John Havlicek", "Bob Cousy"], correct: "Bill Russell" },
            { question: "Hány bajnoki címet nyert Bill Russell?", answers: ["9", "11", "13", "7"], correct: "11" },
            { question: "Melyik csapat a Celtics legnagyobb riválisa?", answers: ["Lakers", "Knicks", "76ers", "Bulls"], correct: "Lakers" },
            { question: "Ki volt a Celtics első afroamerikai játékosa?", answers: ["Chuck Cooper", "Bill Russell", "Sam Jones", "K.C. Jones"], correct: "Chuck Cooper" },
            { question: "Melyik évben nyerte az első bajnoki címét a Celtics?", answers: ["1955", "1957", "1960", "1948"], correct: "1957" },
            { question: "Ki volt a Celtics legendás edzője az 1950-60-as években?", answers: ["Red Auerbach", "Phil Jackson", "Pat Riley", "Gregg Popovich"], correct: "Red Auerbach" },
            { question: "Hány All-Star szereplése volt Larry Birdnek?", answers: ["10", "12", "14", "8"], correct: "12" },
            { question: "Melyik évben vonult vissza Larry Bird?", answers: ["1990", "1992", "1994", "1988"], correct: "1992" },
            { question: "Ki nyerte a 2008-as döntő MVP-je?", answers: ["Paul Pierce", "Kevin Garnett", "Ray Allen", "Rajon Rondo"], correct: "Paul Pierce" },
            { question: "Melyik játékos beceneve 'The Truth'?", answers: ["Paul Pierce", "Kevin Garnett", "Larry Bird", "Jayson Tatum"], correct: "Paul Pierce" },
            { question: "Hány szezonban volt a Celtics az NBA része?", answers: ["75", "77", "79", "73"], correct: "77" },
            { question: "Ki draftolta Jaylen Brownt?", answers: ["Celtics", "Nets", "76ers", "Lakers"], correct: "Celtics" },
            { question: "Melyik évben draftolták Kevin Garnettet?", answers: ["1993", "1995", "1997", "1999"], correct: "1995" },
            { question: "Hány triplát dobott Ray Allen a Celtics színeiben?", answers: ["798", "650", "921", "543"], correct: "798" },
            { question: "Ki volt a Celtics első női segédedzője?", answers: ["Kara Lawson", "Becky Hammon", "Nancy Lieberman", "Lisa Boyer"], correct: "Kara Lawson" },
            { question: "Melyik évben lett Brad Stevens a Celtics edzője?", answers: ["2011", "2013", "2015", "2017"], correct: "2013" },
            { question: "Hány meccset nyert sorozatban a Celtics 2008-2009-ben?", answers: ["19", "17", "15", "21"], correct: "19" },
            { question: "Ki a Celtics kabalafigurája?", answers: ["Lucky", "Benny", "Sly", "Hugo"], correct: "Lucky" },
            { question: "Melyik évben nyerte meg utoljára a Celtics a bajnokságot (2023-ig)?", answers: ["2008", "2010", "2006", "2012"], correct: "2008" },
            { question: "Hány pontot szerzett Jayson Tatum a 2022-es rájátszásban?", answers: ["614", "553", "487", "692"], correct: "614" },
            { question: "Ki volt a Celtics elnöke 2021-től?", answers: ["Brad Stevens", "Danny Ainge", "Red Auerbach", "Rick Pitino"], correct: "Brad Stevens" },
            { question: "Melyik évben lett Bob Cousy az év újonca?", answers: ["1950", "1951", "1952", "1949"], correct: "1951" },
            { question: "Hány All-NBA csapattagsága van Larry Birdnek?", answers: ["9", "10", "11", "8"], correct: "10" },
            { question: "Ki dobta a híres 'buzzer-beater'-t 1987-ben a Lakers ellen?", answers: ["Larry Bird", "Dennis Johnson", "Kevin McHale", "Robert Parish"], correct: "Larry Bird" },
            { question: "Melyik játékos nyert 8 bajnoki címet a Celtics-szel?", answers: ["John Havlicek", "Tom Heinsohn", "Sam Jones", "K.C. Jones"], correct: "John Havlicek" },
            { question: "Hány évig volt Red Auerbach a Celtics edzője?", answers: ["16", "14", "18", "12"], correct: "16" },
            { question: "Melyik évben draftolták Rajon Rondót?", answers: ["2004", "2005", "2006", "2007"], correct: "2006" },
            { question: "Ki volt a Celtics első overall pickje 1950-ben?", answers: ["Chuck Cooper", "Bob Cousy", "Ed Macauley", "Bill Sharman"], correct: "Chuck Cooper" },
            { question: "Hány szezont játszott Paul Pierce a Celtics-nél?", answers: ["13", "15", "17", "11"], correct: "15" },
            { question: "Melyik évben lett Jayson Tatum All-Star?", answers: ["2019", "2020", "2021", "2018"], correct: "2020" },
            { question: "Ki volt a Celtics kapitánya a 80-as években?", answers: ["Larry Bird", "Kevin McHale", "Robert Parish", "Danny Ainge"], correct: "Larry Bird" },
            { question: "Hány pontot szerzett Larry Bird karrierje során?", answers: ["21,791", "19,654", "23,876", "17,432"], correct: "21,791" },
            { question: "Melyik évben nyert először MVP címet Larry Bird?", answers: ["1982", "1984", "1986", "1980"], correct: "1984" },
            { question: "Ki volt a Celtics GM-je a 2008-as bajnoki cím idején?", answers: ["Danny Ainge", "Brad Stevens", "Red Auerbach", "Rick Pitino"], correct: "Danny Ainge" },
            { question: "Hány triplát dobott Jayson Tatum a 2022-23-as szezonban?", answers: ["240", "229", "211", "198"], correct: "229" },
            { question: "Melyik évben lett Kevin McHale All-Star?", answers: ["1984", "1986", "1988", "1982"], correct: "1984" },
            { question: "Ki volt a Celtics legjobb pontszerzője az 1985-86-os szezonban?", answers: ["Larry Bird", "Kevin McHale", "Robert Parish", "Dennis Johnson"], correct: "Larry Bird" },
            { question: "Hány meccset játszott Bill Russell a Celtics-ben?", answers: ["963", "875", "1021", "799"], correct: "963" },
            { question: "Melyik évben draftolták Marcus Smartot?", answers: ["2012", "2013", "2014", "2015"], correct: "2014" },
            { question: "Ki nyerte a 2022-es Keleti döntő MVP címét?", answers: ["Jayson Tatum", "Jaylen Brown", "Marcus Smart", "Al Horford"], correct: "Jayson Tatum" },
            { question: "Hány bajnoki döntőt játszott a Celtics a Lakers ellen?", answers: ["12", "10", "8", "14"], correct: "12" },
            { question: "Melyik évben vonult vissza Bill Russell?", answers: ["1967", "1969", "1971", "1965"], correct: "1969" },
            { question: "Ki volt a Celtics első edzője?", answers: ["John Russell", "Red Auerbach", "Honey Russell", "Doc Rivers"], correct: "Honey Russell" }
        ];

        function getRandomQuestions() {
            const shuffled = allQuestions.sort(() => 0.5 - Math.random());
            return shuffled.slice(0, 10);
        }

        const questions = getRandomQuestions();

        function loadQuiz() {
            const quizContainer = document.getElementById('quiz-container');
            questions.forEach((q, index) => {
                const div = document.createElement('div');
                div.className = 'question';
                div.innerHTML = `
                    <p>${index + 1}. ${q.question}</p>
                    ${q.answers.map((answer, i) => `
                        <input type="radio" name="q${index}" value="${answer}" id="q${index}a${i}">
                        <label for="q${index}a${i}">${answer}</label><br>
                    `).join('')}
                `;
                quizContainer.appendChild(div);
            });
        }

        function checkAnswers() {
            let correctCount = 0;
            questions.forEach((q, index) => {
                const selected = document.querySelector(`input[name="q${index}"]:checked`);
                if (selected && selected.value === q.correct) {
                    correctCount++;
                }
            });

            const resultDiv = document.getElementById('result');
            if (correctCount >= 7) {
                resultDiv.style.color = '#007A33';
                resultDiv.textContent = `Megcsináltad! ${correctCount}/10 - Gratulálunk!`;

                // Visszaküldjük az adatokat a szerverre regisztrációhoz
                fetch('../login_register/index2.php', { // Módosított elérési út
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        'complete_registration': '1',
                        'username': '<?php echo isset($_SESSION["temp_registration"]["username"]) ? $_SESSION["temp_registration"]["username"] : ""; ?>',
                        'email': '<?php echo isset($_SESSION["temp_registration"]["email"]) ? $_SESSION["temp_registration"]["email"] : ""; ?>',
                        'password': '<?php echo isset($_SESSION["temp_registration"]["password"]) ? $_SESSION["temp_registration"]["password"] : ""; ?>'
                    }).toString()
                })
                .then(response => response.text())
                .then(() => {
                    // Sikeres regisztráció üzenet megjelenítése
                    resultDiv.textContent = 'Sikeres regisztráció!';
                    // 2 másodperc várakozás után átirányítás
                    setTimeout(() => {
                        window.location.href = '../login_register/index2.php';
                    }, 2000);
                })
                .catch(error => {
                    console.error('Hiba:', error);
                    resultDiv.textContent = 'Hiba történt a regisztráció során!';
                });
            } else {
                resultDiv.style.color = '#FFFFFF';
                resultDiv.textContent = `Nem sikerült!: ${correctCount}/10 - Ha csatlakozni akarsz, próbáld újra!`;
            }

            // Disable all radio buttons and the button after submission
            document.querySelectorAll('input[type="radio"]').forEach(input => input.disabled = true);
            document.querySelector('button').disabled = true;
        }

        // Timer logic
        let timeLeft = 180; // 3 minutes in seconds
        const timerDisplay = document.getElementById('timer');

        function updateTimer() {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            timerDisplay.textContent = `Hátralévő idő: ${minutes}:${seconds < 10 ? '0' + seconds : seconds}`;

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                timerDisplay.textContent = "Lejárt az idő!";
                checkAnswers(); // Automatically check answers when time is up
            } else {
                timeLeft--;
            }
        }

        // Start the timer when the quiz loads
        const timerInterval = setInterval(updateTimer, 1000);

        loadQuiz();
    </script>
</body>
</html>