const slides = document.querySelectorAll('.carousel-slide');
let currentSlide = 0;

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
    });
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
}

// Automatikus váltás
setInterval(nextSlide, 5000);

// Kezdő slide
showSlide(currentSlide);

// Parallax hatás a háttérre
window.addEventListener('scroll', () => {
    const background = document.querySelector('.background-container');
    const scrollPosition = window.pageYOffset;
    background.style.transform = `translateY(${scrollPosition * 0.5}px)`;
});

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-links a.locked').forEach(link => {
        if (!link.dataset.lockedInitialized) {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                alert('Kérjük, jelentkezz be a tartalom eléréséhez!');
            });
            link.dataset.lockedInitialized = 'true';
        }
    });

    // Évszám frissítése a láblécben
    document.getElementById('year').textContent = new Date().getFullYear();
});